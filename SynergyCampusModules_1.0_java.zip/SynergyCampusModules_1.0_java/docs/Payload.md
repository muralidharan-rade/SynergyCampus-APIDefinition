
# Payload

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**payload** | **String** |  |  [optional]



