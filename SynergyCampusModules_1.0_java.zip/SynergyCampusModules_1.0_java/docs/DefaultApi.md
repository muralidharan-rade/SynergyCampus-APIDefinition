# DefaultApi

All URIs are relative to *https://localhost*

Method | HTTP request | Description
------------- | ------------- | -------------
[**helpdeskComplaintsPost**](DefaultApi.md#helpdeskComplaintsPost) | **POST** /helpdesk/complaints | Create a new ticket
[**helpdeskGetModulesGet**](DefaultApi.md#helpdeskGetModulesGet) | **GET** /helpdesk/getModules | get the ticket modules
[**helpdeskGetTopicGet**](DefaultApi.md#helpdeskGetTopicGet) | **GET** /helpdesk/getTopic | Ticket Topics
[**helpdeskUseridHistoryGet**](DefaultApi.md#helpdeskUseridHistoryGet) | **GET** /helpdesk/{userid}/history | Ticket history of the user


<a name="helpdeskComplaintsPost"></a>
# **helpdeskComplaintsPost**
> helpdeskComplaintsPost(payload)

Create a new ticket

Service to create a new synergy help desk ticket

### Example
```java
// Import classes:
//import org.wso2.client.api.ApiException;
//import org.wso2.client.api.SynergyCampusModules.DefaultApi;


DefaultApi apiInstance = new DefaultApi();
Payload payload = new Payload(); // Payload | Request Body
try {
    apiInstance.helpdeskComplaintsPost(payload);
} catch (ApiException e) {
    System.err.println("Exception when calling DefaultApi#helpdeskComplaintsPost");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **payload** | [**Payload**](Payload.md)| Request Body |

### Return type

null (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="helpdeskGetModulesGet"></a>
# **helpdeskGetModulesGet**
> helpdeskGetModulesGet()

get the ticket modules

### Example
```java
// Import classes:
//import org.wso2.client.api.ApiException;
//import org.wso2.client.api.SynergyCampusModules.DefaultApi;


DefaultApi apiInstance = new DefaultApi();
try {
    apiInstance.helpdeskGetModulesGet();
} catch (ApiException e) {
    System.err.println("Exception when calling DefaultApi#helpdeskGetModulesGet");
    e.printStackTrace();
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

null (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

<a name="helpdeskGetTopicGet"></a>
# **helpdeskGetTopicGet**
> helpdeskGetTopicGet()

Ticket Topics

### Example
```java
// Import classes:
//import org.wso2.client.api.ApiException;
//import org.wso2.client.api.SynergyCampusModules.DefaultApi;


DefaultApi apiInstance = new DefaultApi();
try {
    apiInstance.helpdeskGetTopicGet();
} catch (ApiException e) {
    System.err.println("Exception when calling DefaultApi#helpdeskGetTopicGet");
    e.printStackTrace();
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

null (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

<a name="helpdeskUseridHistoryGet"></a>
# **helpdeskUseridHistoryGet**
> helpdeskUseridHistoryGet(userid)

Ticket history of the user

### Example
```java
// Import classes:
//import org.wso2.client.api.ApiException;
//import org.wso2.client.api.SynergyCampusModules.DefaultApi;


DefaultApi apiInstance = new DefaultApi();
String userid = "userid_example"; // String | 
try {
    apiInstance.helpdeskUseridHistoryGet(userid);
} catch (ApiException e) {
    System.err.println("Exception when calling DefaultApi#helpdeskUseridHistoryGet");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **userid** | **String**|  |

### Return type

null (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

